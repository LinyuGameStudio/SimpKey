package com.lygs.simpkey;

import java.io.File;
import java.io.IOException;
import org.bukkit.configuration.file.YamlConfiguration;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.map.*;
import org.bukkit.plugin.java.JavaPlugin;

import java.awt.image.BufferedImage;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.*;

public final class SimpKey extends JavaPlugin implements Listener {

    private final HttpClient client = HttpClient.newHttpClient();
    private final Map<UUID, String> pending = new HashMap<>();
    private File bindFile;
    private YamlConfiguration bindYaml;

    private String devUuid;
    private String apiHost;
    private int timeout;
    private int interval;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        devUuid  = getConfig().getString("developer-uuid");
        apiHost  = getConfig().getString("api-host");
        timeout  = getConfig().getInt("qr-timeout", 120);
        interval = getConfig().getInt("poll-interval", 1);
        if (devUuid == null || devUuid.length() != 36) {
            getLogger().severe("★★★ config.yml 中 developer-uuid 无效 ★★★");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        bindFile = new File(getDataFolder(), "bindings.yml");
        if (!bindFile.exists()) saveResource("bindings.yml", false);
        bindYaml = YamlConfiguration.loadConfiguration(bindFile);
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("SimpKey 已加载，强制绑定模式开启");
    }

    /* 文件存储工具 */
    private void saveBind(UUID uuid, String openid) {
        bindYaml.set(uuid.toString(), openid);
        try { bindYaml.save(bindFile); } catch (Exception e) {
            getLogger().warning("保存绑定失败: " + e.getMessage());
        }
    }
    private String getBind(UUID uuid) {
        return bindYaml.getString(uuid.toString());
    }
    private void removeBind(UUID uuid) {
        bindYaml.set(uuid.toString(), null);
        try { bindYaml.save(bindFile); } catch (Exception e) {
            getLogger().warning("删除绑定失败: " + e.getMessage());
        }
    }

    /* 进服强制绑定 */
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        if (getBind(p.getUniqueId()) == null) {
            Bukkit.getScheduler().runTaskLater(this, () -> {
                p.sendMessage("§c你尚未完成微信绑定，3 秒后将被踢出！");
                Bukkit.getScheduler().runTaskLater(this, () -> p.kickPlayer("§c请先绑定微信再进服\n§7进服后输入 /simpkey 扫码"), 60L);
            }, 20L);
        }
    }

    /* 命令处理 */
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!cmd.getName().equalsIgnoreCase("simpkey")) return false;
        if (!(sender instanceof Player p)) {
            sender.sendMessage("§c仅玩家可用");
            return true;
        }
        if (args.length > 0 && args[0].equalsIgnoreCase("unbind")) {
            if (getBind(p.getUniqueId()) == null) {
                p.sendMessage("§c你还没有绑定");
                return true;
            }
            removeBind(p.getUniqueId());
            p.sendMessage("§a已解除绑定");
            return true;
        }
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            try {
                /* 1. 申请 OTP  -  GET */
                String url = apiHost + "/api/dev/otp?Developer-UUID=" + devUuid;
                HttpRequest req = HttpRequest.newBuilder()
                        .uri(URI.create(url))
                        .header("Content-Type", "application/json")
                        .GET()
                        .timeout(Duration.ofSeconds(5))
                        .build();
                HttpResponse<String> rsp = client.send(req, HttpResponse.BodyHandlers.ofString());
                JsonObject res = JsonParser.parseString(rsp.body()).getAsJsonObject();
                if (!"200".equals(res.get("code").getAsString())) {
                    p.sendMessage("§c获取码失败: " + (res.has("msg") ? res.get("msg").getAsString() : "未知错误"));
                    return;
                }
                JsonObject data = res.getAsJsonObject("data");
                String otpUrl = data.get("otp_url").getAsString();
                String sid    = data.get("sid").getAsString();

                /* 2. 生成二维码地图 */
                QRCodeWriter writer = new QRCodeWriter();
                BitMatrix matrix = writer.encode(otpUrl, BarcodeFormat.QR_CODE, 128, 128);
                BufferedImage image = toBufferedImage(matrix);
                MapView map = Bukkit.createMap(p.getWorld());
                map.getRenderers().clear();
                map.addRenderer(new QRMapRenderer(image));
                ItemStack mapItem = new ItemStack(Material.FILLED_MAP, 1);
                mapItem.setDurability((short) map.getId());
                p.getInventory().addItem(mapItem);
                p.sendMessage("§a请用微信扫描二维码完成绑定！");

                /* 3. 轮询 - GET */
                pending.put(p.getUniqueId(), sid);
                pollOTP(p, p.getUniqueId());
            } catch (Exception e) {
                p.sendMessage("§c出错: " + e.getMessage());
            }
        });
        return true;
    }

    /* 轮询 OTP 状态 - GET */
    private void pollOTP(Player p, UUID uid) {
        class PollTask implements Runnable {
            private int left = timeout;
            @Override
            public void run() {
                if (!p.isOnline() || left-- <= 0) {
                    pending.remove(uid);
                    return;
                }
                Bukkit.getScheduler().runTaskAsynchronously(SimpKey.this, () -> {
                    try {
                        String url = apiHost + "/api/dev/otp?sid=" + pending.get(uid) + "&Developer-UUID=" + devUuid;
                        HttpRequest req = HttpRequest.newBuilder()
                                .uri(URI.create(url))
                                .GET()
                                .timeout(Duration.ofSeconds(5))
                                .build();
                        HttpResponse<String> rsp = client.send(req, HttpResponse.BodyHandlers.ofString());
                        JsonObject res = JsonParser.parseString(rsp.body()).getAsJsonObject();
                        if (!"200".equals(res.get("code").getAsString())) return;
                        JsonObject d = res.getAsJsonObject("data");
                        if (d.get("status").getAsInt() == 1) {
                            String openid = d.getAsJsonObject("user_info").get("openid").getAsString();
                            Bukkit.getScheduler().runTask(SimpKey.this, () -> {
                                saveBind(p.getUniqueId(), openid);
                                p.sendMessage("§a✔ 绑定成功！openid=" + openid);
                            });
                            pending.remove(uid);
                            return;
                        }
                    } catch (Exception ignored) {}
                    Bukkit.getScheduler().runTaskLater(SimpKey.this, new PollTask(), 20L * interval);
                });
            }
        }
        Bukkit.getScheduler().runTaskLater(this, new PollTask(), 20L * interval);
    }

    /* 工具：BitMatrix -> BufferedImage */
    private static BufferedImage toBufferedImage(BitMatrix matrix) {
        int w = matrix.getWidth();
        int h = matrix.getHeight();
        BufferedImage img = new BufferedImage(w, h, BufferedImage.TYPE_INT_RGB);
        for (int x = 0; x < w; x++) {
            for (int y = 0; y < h; y++) {
                img.setRGB(x, y, matrix.get(x, y) ? 0x000000 : 0xFFFFFF);
            }
        }
        return img;
    }

    /* 地图渲染器 */
    private static class QRMapRenderer extends MapRenderer {
        private final BufferedImage img;
        private boolean done = false;
        QRMapRenderer(BufferedImage img) { this.img = img; }
        @Override
        public void render(MapView view, MapCanvas canvas, Player player) {
            if (done) return;
            for (int x = 0; x < 128; x++) {
                for (int z = 0; z < 128; z++) {
                    canvas.setPixel(x, z, (byte) (img.getRGB(x, z) == 0x000000 ? 0 : 1));
                }
            }
            done = true;
        }
    }
}